/*
  # Restaurant Website Database Schema

  This migration creates the complete database structure for a premium restaurant website
  with menu items, gallery images, and contact form submissions.

  ## New Tables

  ### menu_items
  - `id`: uuid primary key
  - `name`: item name
  - `description`: detailed description
  - `price`: item price in decimal
  - `category`: starter, main, drinks, desserts, special
  - `image_url`: high-quality image URL from Pexels
  - `rating`: customer rating (0-5)
  - `is_popular`: boolean for popular item tags
  - `is_available`: boolean for item availability
  - `created_at`: timestamp

  ### gallery_images
  - `id`: uuid primary key
  - `title`: image title
  - `category`: food, interior, customers, ambience, chef, signature
  - `image_url`: image URL from Pexels
  - `description`: image description
  - `display_order`: order for display
  - `created_at`: timestamp

  ### contact_submissions
  - `id`: uuid primary key
  - `name`: contact name
  - `email`: contact email
  - `phone`: contact phone
  - `message`: contact message
  - `created_at`: timestamp

  ### reviews
  - `id`: uuid primary key
  - `name`: reviewer name
  - `rating`: rating (1-5)
  - `comment`: review comment
  - `is_featured`: boolean for featured reviews
  - `created_at`: timestamp

  ## Security
  - RLS enabled on all tables
  - Read access for menu_items and gallery_images (public)
  - Write access for contact_submissions (public)
  - Restricted access for reviews (public read, authenticated write)
*/

-- Create menu_items table
CREATE TABLE IF NOT EXISTS menu_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text NOT NULL,
  price decimal(10, 2) NOT NULL,
  category text NOT NULL CHECK (category IN ('starter', 'main', 'drinks', 'desserts', 'special')),
  image_url text NOT NULL,
  rating decimal(3, 2) DEFAULT 4.5 CHECK (rating >= 0 AND rating <= 5),
  is_popular boolean DEFAULT false,
  is_available boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

-- Create gallery_images table
CREATE TABLE IF NOT EXISTS gallery_images (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  category text NOT NULL CHECK (category IN ('food', 'interior', 'customers', 'ambience', 'chef', 'signature')),
  image_url text NOT NULL,
  description text DEFAULT '',
  display_order integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- Create contact_submissions table
CREATE TABLE IF NOT EXISTS contact_submissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  email text NOT NULL,
  phone text DEFAULT '',
  message text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create reviews table
CREATE TABLE IF NOT EXISTS reviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  rating integer NOT NULL CHECK (rating >= 1 AND rating <= 5),
  comment text NOT NULL,
  is_featured boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS on all tables
ALTER TABLE menu_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE gallery_images ENABLE ROW LEVEL SECURITY;
ALTER TABLE contact_submissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE reviews ENABLE ROW LEVEL SECURITY;

-- RLS policies for menu_items (public read)
CREATE POLICY "Menu items are publicly readable"
  ON menu_items FOR SELECT
  TO public
  USING (true);

-- RLS policies for gallery_images (public read)
CREATE POLICY "Gallery images are publicly readable"
  ON gallery_images FOR SELECT
  TO public
  USING (true);

-- RLS policies for contact_submissions (public insert only)
CREATE POLICY "Contact submissions can be created by anyone"
  ON contact_submissions FOR INSERT
  TO public
  WITH CHECK (true);

-- RLS policies for reviews (public read)
CREATE POLICY "Reviews are publicly readable"
  ON reviews FOR SELECT
  TO public
  USING (true);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_menu_items_category ON menu_items(category);
CREATE INDEX IF NOT EXISTS idx_gallery_images_category ON gallery_images(category);
CREATE INDEX IF NOT EXISTS idx_gallery_images_order ON gallery_images(display_order);
CREATE INDEX IF NOT EXISTS idx_reviews_featured ON reviews(is_featured);

-- Insert sample menu items
INSERT INTO menu_items (name, description, price, category, image_url, rating, is_popular) VALUES
  -- Starters
  ('Truffle Arancini', 'Crispy risotto balls with black truffle and parmesan, served with wild mushroom aioli', 18.00, 'starter', 'https://images.pexels.com/photos/1647163/pexels-photo-1647163.jpeg?auto=compress&cs=tinysrgb&w=800', 4.8, true),
  ('Tuna Tataki', 'Seared yellowfin tuna with ponzu, wasabi, and microgreens', 22.00, 'starter', 'https://images.pexels.com/photos/2878726/pexels-photo-2878726.jpeg?auto=compress&cs=tinysrgb&w=800', 4.7, false),
  ('Burrata Salad', 'Fresh burrata, heirloom tomatoes, basil pesto, aged balsamic', 16.00, 'starter', 'https://images.pexels.com/photos/1437268/pexels-photo-1437268.jpeg?auto=compress&cs=tinysrgb&w=800', 4.6, true),
  
  -- Main Course
  ('Wagyu Ribeye', '12oz Australian wagyu, bone marrow butter, roasted vegetables, red wine jus', 85.00, 'main', 'https://images.pexels.com/photos/2474660/pexels-photo-2474660.jpeg?auto=compress&cs=tinysrgb&w=800', 4.9, true),
  ('Pan-Seared Salmon', 'Scottish salmon, lemon beurre blanc, asparagus, fingerling potatoes', 38.00, 'main', 'https://images.pexels.com/photos/769289/pexels-photo-769289.jpeg?auto=compress&cs=tinysrgb&w=800', 4.7, false),
  ('Lobster Linguine', 'Maine lobster, cherry tomatoes, garlic, white wine, fresh herbs', 56.00, 'main', 'https://images.pexels.com/photos/1566835/pexels-photo-1566835.jpeg?auto=compress&cs=tinysrgb&w=800', 4.8, true),
  ('Duck Confit', 'Slow-cooked duck leg, cherry gastrique, roasted root vegetables', 42.00, 'main', 'https://images.pexels.com/photos/1402361/pexels-photo-1402361.jpeg?auto=compress&cs=tinysrgb&w=800', 4.6, false),
  
  -- Drinks
  ('Signature Martini', 'Premium vodka, elderflower liqueur, champagne, edible flowers', 18.00, 'drinks', 'https://images.pexels.com/photos/3323790/pexels-photo-3323790.jpeg?auto=compress&cs=tinysrgb&w=800', 4.9, true),
  ('Craft Old Fashioned', 'Bourbon, house-made bitters, brown sugar, orange peel', 16.00, 'drinks', 'https://images.pexels.com/photos/1662109/pexels-photo-1662109.jpeg?auto=compress&cs=tinysrgb&w=800', 4.7, false),
  ('Champagne Flight', 'Three glasses of premium champagne (Dom Pérignon, Veuve Clicquot, Moët)', 45.00, 'drinks', 'https://images.pexels.com/photos/2122417/pexels-photo-2122417.jpeg?auto=compress&cs=tinysrgb&w=800', 4.8, true),
  
  -- Desserts
  ('Chocolate Lava Cake', 'Warm molten chocolate cake, vanilla gelato, raspberry coulis', 14.00, 'desserts', 'https://images.pexels.com/photos/291522/pexels-photo-291522.jpeg?auto=compress&cs=tinysrgb&w=800', 4.9, true),
  ('Crème Brûlée', 'Classic vanilla custard, caramelized sugar, fresh berries', 12.00, 'desserts', 'https://images.pexels.com/photos/14774956/pexels-photo-14774956.jpeg?auto=compress&cs=tinysrgb&w=800', 4.7, false),
  ('Tiramisu', 'Espresso-soaked ladyfingers, mascarpone, cocoa, coffee liqueur', 13.00, 'desserts', 'https://images.pexels.com/photos/14846933/pexels-photo-14846933.jpeg?auto=compress&cs=tinysrgb&w=800', 4.8, true),
  
  -- Special Items
  ('Chef''s Tasting Menu', 'Seven-course tasting experience with wine pairing', 150.00, 'special', 'https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg?auto=compress&cs=tinysrgb&w=800', 5.0, true),
  ('Truffle Degustation', 'Five-course truffle-themed menu with seasonal ingredients', 125.00, 'special', 'https://images.pexels.com/photos/2608049/pexels-photo-2608049.jpeg?auto=compress&cs=tinysrgb&w=800', 4.9, true);

-- Insert sample gallery images
INSERT INTO gallery_images (title, category, image_url, description, display_order) VALUES
  ('Culinary Masterpiece', 'signature', 'https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg?auto=compress&cs=tinysrgb&w=1200', 'Our signature dish presentation', 1),
  ('Modern Interior', 'interior', 'https://images.pexels.com/photos/2609311/pexels-photo-2609311.jpeg?auto=compress&cs=tinysrgb&w=1200', 'Elegant dining space with ambient lighting', 2),
  ('Chef at Work', 'chef', 'https://images.pexels.com/photos/1267320/pexels-photo-1267320.jpeg?auto=compress&cs=tinysrgb&w=1200', 'Our executive chef crafting culinary art', 3),
  ('Artisan Pizza', 'food', 'https://images.pexels.com/photos/4109131/pexels-photo-4109131.jpeg?auto=compress&cs=tinysrgb&w=1200', 'Handcrafted pizza fresh from our wood oven', 4),
  ('Wine Cellar', 'ambience', 'https://images.pexels.com/photos/2608999/pexels-photo-2608999.jpeg?auto=compress&cs=tinysrgb&w=1200', 'Our curated wine collection', 5),
  ('Happy Guests', 'customers', 'https://images.pexels.com/photos/2620474/pexels-photo-2620474.jpeg?auto=compress&cs=tinysrgb&w=1200', 'Guests enjoying their dining experience', 6),
  ('Fresh Ingredients', 'food', 'https://images.pexels.com/photos/1640774/pexels-photo-1640774.jpeg?auto=compress&cs=tinysrgb&w=1200', 'Farm-to-table fresh ingredients', 7),
  ('Bar Area', 'interior', 'https://images.pexels.com/photos/2789347/pexels-photo-2789347.jpeg?auto=compress&cs=tinysrgb&w=1200', 'Sophisticated bar lounge', 8),
  ('Plating Art', 'signature', 'https://images.pexels.com/photos/2608049/pexels-photo-2608049.jpeg?auto=compress&cs=tinysrgb&w=1200', 'Artistic plating by our culinary team', 9),
  ('Private Dining', 'ambience', 'https://images.pexels.com/photos/2841419/pexels-photo-2841419.jpeg?auto=compress&cs=tinysrgb&w=1200', 'Exclusive private dining room', 10),
  ('Gourmet Presentation', 'food', 'https://images.pexels.com/photos/2297961/pexels-photo-2297961.jpeg?auto=compress&cs=tinysrgb&w=1200', 'Exquisite gourmet presentation', 11),
  ('Evening Atmosphere', 'ambience', 'https://images.pexels.com/photos/2608972/pexels-photo-2608972.jpeg?auto=compress&cs=tinysrgb&w=1200', 'Romantic evening ambiance', 12);

-- Insert sample reviews
INSERT INTO reviews (name, rating, comment, is_featured) VALUES
  ('Sarah Johnson', 5, 'An absolutely incredible dining experience! The Chef''s Tasting Menu was worth every penny. The ambiance, service, and attention to detail exceeded all expectations.', true),
  ('Michael Chen', 5, 'Best restaurant in the city. The wagyu ribeye was cooked to perfection, and the wine pairing recommendations were spot on. Will definitely return!', true),
  ('Emily Davis', 5, 'From the moment we walked in, we felt like royalty. The truffle arancini is a must-try, and the chocolate lava cake was divine!', true),
  ('David Thompson', 4, 'Great atmosphere and delicious food. The only slight downside was a brief wait for our table, but the experience was well worth it.', false),
  ('Jessica Martinez', 5, 'Celebrated our anniversary here and it was magical. The staff made us feel so special, and the signature cocktails were amazing!', true),
  ('Robert Wilson', 5, 'Exceptional quality across the board. The tasting menu showcases incredible creativity and technique. A true culinary journey.', false);
