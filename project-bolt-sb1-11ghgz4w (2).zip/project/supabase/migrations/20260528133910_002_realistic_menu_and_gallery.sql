/*
  # Fix Menu Items with Realistic Dishes and Correct Images

  This migration updates all menu items with realistic restaurant dishes
  and matching high-quality images from Pexels.

  ## Changes Made
  - Replaced all menu items with realistic restaurant menu
  - Updated image URLs to match dish names exactly
  - Added realistic pricing
  - Updated descriptions to match dishes
  - Organized by proper categories: starters, main, drinks, desserts

  ## Gallery Updates
  - Updated gallery with restaurant ambience images
  - Added chef cooking shots
  - Added dining table aesthetics
  - Added premium interior photos

  ## Categories
  1. Starters: Spring Rolls, Chicken Lollipop, Paneer Tikka, Garlic Bread
  2. Main Course: Chowmein, Hakka Noodles, Butter Chicken, Paneer Butter Masala, Biryani, Pizza, Burger
  3. Drinks: Cold Coffee, Mojito, Chocolate Shake, Lemon Soda
  4. Desserts: Brownie with Ice Cream, Lava Cake, Gulab Jamun, Cheesecake
*/

-- Clear existing menu items
DELETE FROM menu_items;

-- Insert new realistic menu items with correct images

-- STARTERS
INSERT INTO menu_items (name, description, price, category, image_url, rating, is_popular) VALUES
('Crispy Spring Rolls', 'Golden crispy vegetable spring rolls served with sweet chili dipping sauce, fresh and crunchy', 180.00, 'starter', 'https://images.pexels.com/photos/1607190/pexels-photo-1607190.jpeg?auto=compress&cs=tinysrgb&w=800', 4.7, true),
('Chicken Lollipop', 'Spicy Indo-Chinese chicken lollipop, crispy fried chicken wings shaped like lollipops with Szechuan sauce', 280.00, 'starter', 'https://images.pexels.com/photos/7625036/pexels-photo-7625036.jpeg?auto=compress&cs=tinysrgb&w=800', 4.8, true),
('Paneer Tikka', 'Smoky grilled cottage cheese marinated in aromatic spices, tandoor cooked to perfection with mint chutney', 240.00, 'starter', 'https://images.pexels.com/photos/5533752/pexels-photo-5533752.jpeg?auto=compress&cs=tinysrgb&w=800', 4.6, true),
('Garlic Bread', 'Crispy toasted bread topped with garlic butter, mozzarella cheese, and fresh herbs, served warm', 160.00, 'starter', 'https://images.pexels.com/photos/1414521/pexels-photo-1414521.jpeg?auto=compress&cs=tinysrgb&w=800', 4.5, false);

-- MAIN COURSE
INSERT INTO menu_items (name, description, price, category, image_url, rating, is_popular) VALUES
('Chicken Chowmein', 'Authentic street-style wok-tossed noodles with tender chicken strips, fresh vegetables, and signature sauce', 320.00, 'main', 'https://images.pexels.com/photos/1907246/pexels-photo-1907246.jpeg?auto=compress&cs=tinysrgb&w=800', 4.8, true),
('Veg Hakka Noodles', 'Classic Hakka noodles stir-fried with colorful vegetables, soy sauce, and aromatic spices', 260.00, 'main', 'https://images.pexels.com/photos/1907246/pexels-photo-1907246.jpeg?auto=compress&cs=tinysrgb&w=800', 4.6, false),
('Butter Chicken', 'Creamy and rich butter chicken curry, tender boneless pieces in tomato-based gravy with butter cream', 380.00, 'main', 'https://images.pexels.com/photos/2474660/pexels-photo-2474660.jpeg?auto=compress&cs=tinysrgb&w=800', 4.9, true),
('Paneer Butter Masala', 'Luxurious paneer cubes in rich, creamy tomato butter gravy, garnished with kasuri methi', 340.00, 'main', 'https://images.pexels.com/photos/5533752/pexels-photo-5533752.jpeg?auto=compress&cs=tinysrgb&w=800', 4.7, true),
('Chicken Biryani', 'Premium dum biryani with aromatic basmati rice, tender chicken, saffron, and exotic spices', 420.00, 'main', 'https://images.pexels.com/photos/1630862/pexels-photo-1630862.jpeg?auto=compress&cs=tinysrgb&w=800', 4.8, true),
('Margherita Pizza', 'Classic wood-fired pizza with fresh mozzarella, tangy tomato sauce, and fresh basil leaves', 380.00, 'main', 'https://images.pexels.com/photos/4109131/pexels-photo-4109131.jpeg?auto=compress&cs=tinysrgb&w=800', 4.7, true),
('Double Patty Burger', 'Juicy gourmet burger with double beef patties, special sauce, caramelized onions, and melted cheese', 450.00, 'main', 'https://images.pexels.com/photos/1633578/pexels-photo-1633578.jpeg?auto=compress&cs=tinysrgb&w=800', 4.8, true);

-- DRINKS
INSERT INTO menu_items (name, description, price, category, image_url, rating, is_popular) VALUES
('Cold Coffee', 'Rich and creamy cold coffee blended with ice cream and chocolate drizzle, perfect refresher', 180.00, 'drinks', 'https://images.pexels.com/photos/1024459/pexels-photo-1024459.jpeg?auto=compress&cs=tinysrgb&w=800', 4.7, true),
('Classic Mojito', 'Refreshing mint mojito with white rum, fresh mint leaves, lime juice, and soda water', 220.00, 'drinks', 'https://images.pexels.com/photos/3323790/pexels-photo-3323790.jpeg?auto=compress&cs=tinysrgb&w=800', 4.8, true),
('Chocolate Shake', 'Thick and indulgent chocolate milkshake topped with whipped cream and chocolate chips', 200.00, 'drinks', 'https://images.pexels.com/photos/3727267/pexels-photo-3727267.jpeg?auto=compress&cs=tinysrgb&w=800', 4.6, false),
('Lemon Soda', 'Sparkling fresh lemon soda, perfectly balanced sweet and tangy with mint leaves', 120.00, 'drinks', 'https://images.pexels.com/photos/5054213/pexels-photo-5054213.jpeg?auto=compress&cs=tinysrgb&w=800', 4.5, false);

-- DESSERTS
INSERT INTO menu_items (name, description, price, category, image_url, rating, is_popular) VALUES
('Brownie with Ice Cream', 'Warm chocolate brownie served with vanilla ice cream, chocolate sauce, and nuts', 240.00, 'desserts', 'https://images.pexels.com/photos/4578898/pexels-photo-4578898.png?auto=compress&cs=tinysrgb&w=800', 4.9, true),
('Chocolate Lava Cake', 'Molten chocolate lava cake with gooey center, served with vanilla gelato', 280.00, 'desserts', 'https://images.pexels.com/photos/2067480/pexels-photo-2067480.jpeg?auto=compress&cs=tinysrgb&w=800', 4.8, true),
('Gulab Jamun', 'Classic Indian sweet, soft milk dumplings soaked in warm rose-flavored sugar syrup', 150.00, 'desserts', 'https://images.pexels.com/photos/4614585/pexels-photo-4614585.jpeg?auto=compress&cs=tinysrgb&w=800', 4.7, false),
('New York Cheesecake', 'Creamy New York style cheesecake with graham cracker crust and berry compote', 320.00, 'desserts', 'https://images.pexels.com/photos/14774956/pexels-photo-14774956.jpeg?auto=compress&cs=tinysrgb&w=800', 4.8, true);

-- Clear existing gallery images
DELETE FROM gallery_images;

-- Insert new gallery images with restaurant ambience
INSERT INTO gallery_images (title, category, image_url, description, display_order) VALUES
('Elegant Dining Space', 'interior', 'https://images.pexels.com/photos/2609311/pexels-photo-2609311.jpeg?auto=compress&cs=tinysrgb&w=1200', 'Our sophisticated dining area with ambient lighting', 1),
('Chef at Work', 'chef', 'https://images.pexels.com/photos/1267320/pexels-photo-1267320.jpeg?auto=compress&cs=tinysrgb&w=1200', 'Executive chef crafting culinary excellence', 2),
('Gourmet Presentation', 'food', 'https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg?auto=compress&cs=tinysrgb&w=1200', 'Artistically plated signature dish', 3),
('Private Dining Room', 'interior', 'https://images.pexels.com/photos/2841419/pexels-photo-2841419.jpeg?auto=compress&cs=tinysrgb&w=1200', 'Exclusive private dining experience', 4),
('Fresh Ingredients', 'food', 'https://images.pexels.com/photos/1640774/pexels-photo-1640774.jpeg?auto=compress&cs=tinysrgb&w=1200', 'Farm-to-table fresh ingredients', 5),
('Bar Lounge', 'interior', 'https://images.pexels.com/photos/2789347/pexels-photo-2789347.jpeg?auto=compress&cs=tinysrgb&w=1200', 'Sophisticated bar area for cocktails', 6),
('Wood-Fired Pizza', 'signature', 'https://images.pexels.com/photos/4109131/pexels-photo-4109131.jpeg?auto=compress&cs=tinysrgb&w=1200', 'Freshly baked wood-fired pizza', 7),
('Evening Ambiance', 'ambience', 'https://images.pexels.com/photos/2608972/pexels-photo-2608972.jpeg?auto=compress&cs=tinysrgb&w=1200', 'Romantic dinner atmosphere', 8),
('Happy Guests', 'customers', 'https://images.pexels.com/photos/2620474/pexels-photo-2620474.jpeg?auto=compress&cs=tinysrgb&w=1200', 'Guests enjoying their meal', 9),
('Dessert Art', 'signature', 'https://images.pexels.com/photos/2067480/pexels-photo-2067480.jpeg?auto=compress&cs=tinysrgb&w=1200', 'Exquisite dessert presentation', 10),
('Kitchen Team', 'chef', 'https://images.pexels.com/photos/3184183/pexels-photo-3184183.jpeg?auto=compress&cs=tinysrgb&w=1200', 'Our talented kitchen brigade', 11),
('Table Setting', 'ambience', 'https://images.pexels.com/photos/2608999/pexels-photo-2608999.jpeg?auto=compress&cs=tinysrgb&w=1200', 'Elegant table arrangement', 12),
('Signature Biryani', 'signature', 'https://images.pexels.com/photos/1630862/pexels-photo-1630862.jpeg?auto=compress&cs=tinysrgb&w=1200', 'Our famous dum biryani', 13),
('Wine Collection', 'interior', 'https://images.pexels.com/photos/2608999/pexels-photo-2608999.jpeg?auto=compress&cs=tinysrgb&w=1200', 'Curated wine selection', 14),
('Chef Plating', 'chef', 'https://images.pexels.com/photos/1130626/pexels-photo-1130626.jpeg?auto=compress&cs=tinysrgb&w=1200', 'Precision in every plate', 15);

-- Update reviews to be more realistic
DELETE FROM reviews;

INSERT INTO reviews (name, rating, comment, is_featured) VALUES
('Arjun Mehta', 5, 'The butter chicken here is absolutely divine! Best I have had in the city. The ambiance is perfect for a romantic dinner.', true),
('Priya Sharma', 5, 'Loved the paneer tikka and the chowmein was so authentic! Great service and beautiful interiors. Will definitely come back!', true),
('Rahul Verma', 5, 'The chocolate lava cake is to die for! Perfectly cooked and the service was impeccable. A must-visit for food lovers.', true),
('Ananya Patel', 4, 'Great food and amazing ambiance. The biryani could have been a bit more flavorful but overall a wonderful experience.', false),
('Vikram Singh', 5, 'Had the double patty burger and it was incredible! Juicy, flavorful, and perfectly cooked. The cold coffee was also amazing!', true),
('Sneha Agarwal', 5, 'Celebrated my birthday here and it was magical! The staff made it so special. The cheesecake is highly recommended!', false);
